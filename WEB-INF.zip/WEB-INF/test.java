public class test{
	public static void main(String[] args){
		String t = "Esm\'e";
		t = t.replace("'","");
		System.out.println(t);
	}
}
