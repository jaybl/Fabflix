class MyConstants{


    public static String SITE_KEY ="6Lf4DyEUAAAAAL16reEpjJvkRjmyjHsmVe0-7e66";

    public static String SECRET_KEY ="6Lf4DyEUAAAAAAfJOQbvgFvy7gAtMNdr_aE8egNu";

}

